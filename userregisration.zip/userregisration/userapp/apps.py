from django.apps import AppConfig


class UesrappConfig(AppConfig):
    name = 'userapp'
