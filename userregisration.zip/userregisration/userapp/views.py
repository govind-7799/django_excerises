from django.shortcuts import render
from .forms import Userpage


def showpage(request):
    if request.method == 'post':
        fm = Userpage(request.post)
        if fm.is_valid():
            user = fm.cleaned_data['username']
            em = fm.cleaned_data['email']
            ps = fm.cleaned_data['password']
            fm.save()
        return render(request, 'one.html',{'fm': fm})
    else:
        fm = Userpage()
        return render(request, 'one.html', {'fm':fm})


def showdata(request):
    if request.method == 'post':
        fm = Userpage(request.post)
        if fm.is_valid():
            user = fm.cleaned_data['username']
            em = fm.cleaned_data['email']
            ps = fm.cleaned_data['password']
            fm.save()
        return render(request, 'two.html',{'fm': fm})
    else:
        fm = Userpage()
        return render(request, 'two.html', {'fm':fm})












