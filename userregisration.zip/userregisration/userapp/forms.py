from django import forms


class Userpage(forms.Form):
    first_name=forms.CharField(max_length=50)
    last_name=forms.CharField(max_length=50)
    username = forms.CharField(max_length=40,initial='@')
    email = forms.EmailField()
    password = forms.CharField()
    message = forms.CharField(max_length=50,help_text='Write here your message!')

