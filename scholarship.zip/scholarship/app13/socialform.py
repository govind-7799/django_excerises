from django import forms
from .models import Demopage


class Hellodata(forms.ModelForm):
    class Meta:
        model = Demopage
        fields = '__all__'







