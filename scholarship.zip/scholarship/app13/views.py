from django.shortcuts import render
from .models import Demopage
from app13.forms import Hellodata


# Create your views here.
def demodata(request):

    if request.method == 'POST':
        fm = Hellodata(request.POST)

        if fm.is_valid():
           nm = fm.cleaned_data['name']
           no= fm.cleaned_data['no']
           em = fm.cleaned_data['email']
           cn=fm.cleaned_data['contact_no']
           reg = Demopage(name=nm, no=no, email=em,contact_no=cn)
           reg.save()
        return render(request, 'one.html',{'form':fm})
    else:
        fm = Hellodata()
        return render(request, 'one.html',{'form':fm})
