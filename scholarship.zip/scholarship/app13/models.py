from django.db import models


class Demopage(models.Model):
    name = models.CharField(max_length=50)
    dob = models.DateField()
    email = models.EmailField()
    phoneno = models.IntegerField()
    address = models.CharField(max_length=200)

