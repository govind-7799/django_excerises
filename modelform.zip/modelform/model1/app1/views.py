from django.shortcuts import render
from .models import Info
from .forms import InfoDetails


def showinfo(request):

    if request.method == 'POST':
        fm = InfoDetails(request.POST)

        if fm.is_valid():
           nm = fm.cleaned_data['name']
           no= fm.cleaned_data['no']
           em = fm.cleaned_data['email']
           cn=fm.cleaned_data['contact_no']
           reg = Info(name=nm, no=no, email=em,contact_no=cn)
           reg.save()
        return render(request, 'one.html',{'form':fm})
    else:
        fm = InfoDetails()
        return render(request, 'one.html',{'form':fm})