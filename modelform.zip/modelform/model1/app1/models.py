from django.db import models



class Info(models.Model):
    name = models.CharField(max_length=40,)
    no = models.IntegerField()
    email = models.EmailField()
    contact_no = models.IntegerField()


