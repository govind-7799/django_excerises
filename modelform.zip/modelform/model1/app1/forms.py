from django import forms
from .models import Info


class InfoDetails(forms.ModelForm):
    class Meta:
        model = Info
        fields = ['name','no','email','contact_no']
        labels = {'name':'please enter your name','no':'enter your no'}
        help_text = {'contact_no':'enter your number'}



