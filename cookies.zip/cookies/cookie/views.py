from django.shortcuts import render


# Create your views here.
def set_cookie(request):
    res = render(request, 'cookies.html')
    res.set_cookie('bookname', 'SleepWell', max_age=100, expires=None)
    return res


def get_cookie(request):
    bookname = request.COOKIES.get('bookname')
    return render(request, 'cookies1.html', {'bookname': bookname})

def delete_cookie():
    pass