
from django.db import models


# Create your models here.
class Crud_model(models.Model):
    Room_choices = (

        ('normal', 'Normal'),
        ('Ac', 'Ac'),
        ('Delux', 'Delux')
    )
    RoomType = models.CharField(choices=Room_choices, max_length=10)
    num_of_guests = models.IntegerField()
    Fullname = models.CharField(max_length=10)
    start_date = models.DateField()
    end_date = models.DateField()
    mob = models.IntegerField(unique=True)
    email = models.EmailField()
    message = models.CharField(max_length=20)
