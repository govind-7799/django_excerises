from django.shortcuts import render,HttpResponseRedirect
from one.forms import Signup
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate,login,logout

#-----------------------------------------------------------#

from one.models import Crud_model
from one.forms import Curd_form
from django.http import HttpResponseRedirect
from django.views import View
# Create your views here.

class home_page(View):
    def get(self, request):
        return render(request,'home.html')


class signup(View):
    def post(self, request):
        fm = Signup(request.POST)
        if fm.is_valid():
            messages.success(request,'account created sucssesfully')
            fm.save()

    def get(self, request):
        fm = Signup()
        return render(request,'signup.html',{'form':fm})


class login_page(View):
    def post(self, request):
            fm = AuthenticationForm(request=request,data=request.POST)
            if fm.is_valid():
                username = fm.cleaned_data['username']
                password = fm.cleaned_data['password']
                db=authenticate(username=username,password=password)
                db.save()
                if db is not None:
                    login(request,db)
                    messages.success(request,'Updated Succssesfully')
                    return HttpResponseRedirect('/profile/')
    def get(self, request):
            fm = AuthenticationForm()
            return render(request,'login.html',{'form':fm})

class first_page(View):
    def get(self, request):
        return render(request, 'userprofile.html')


def profile_page(request):
    if request.user.is_authenticated:
        return render(request, 'userprofile.html', {"name": request.user})
    else:
        return HttpResponseRedirect('/login/')

def logoutuser(request):
    logout(request)
    return HttpResponseRedirect('/login/')






# Create your views here.
class Crud(View):
    def post(self,request):
        fm = Curd_form(request.POST)
        if fm.is_valid():
            RoomType = fm.cleaned_data['RoomType']
            num_of_guests = fm.cleaned_data['num_of_guests']
            Fullname = fm.cleaned_data['Fullname']
            start_date = fm.cleaned_data['start_date']
            end_date = fm.cleaned_data['end_date']
            mob = fm.cleaned_data['mob']
            email = fm.cleaned_data['email']
            message = fm.cleaned_data['message']

            db = Crud_model(RoomType=RoomType,num_of_guests=num_of_guests,Fullname=Fullname,start_date=start_date,end_date=end_date,mob=mob,email=email,message=message)
            db.save()
            fm = Curd_form()

    def get(self, request):
        fm = Curd_form()
        data = Crud_model.objects.all()
        return render(request,'index.html',{'form':fm,'fetch': data})
class update_view(View):
    def post(self,request,id):
        pi = Crud_model.objects.get(pk=id)
        fm = Curd_form(request.POST,instance=pi)
        if fm.is_valid():
            fm.save()
            messages.info(request,'Data Updated Successfully')

    def get(self, request, id):
        pi = Crud_model.objects.get(pk=id)
        fm = Curd_form(instance=pi)

        return render(request,'update.html',{'form':fm})
class delete_view(View):
    def get(self, request, id):
        fm = Crud_model.objects.get(pk=id)
        fm.delete()
        return HttpResponseRedirect('/')



def get_session(request):
    name = request.session['name']
    id = request.session['id']
    # name = request.session.get('name', default = 'Guest')
    # keys = request.session.keys()
    # key = request.session.items()
    # age = request.session.setdefault('age', '36')
    request.session.modified = True
    context = {'name': name, 'id': id}
    return render(request, 'get_session1.html',context )

def del_session(request):
    # if 'name' in request.session:
    #     del request.session['name']
    request.session.flush()
    request.session.clear_expired()
    return render(request, 'del_session1.html')

def get_cookie(request):
    # name = request.COOKIES.get('name','Guest')
    com_name = request.get_signed_cookie('movie_name', default = 'Guest',salt = 'movie_name')
    # name = request.COOKIES['name']
    return render(request, 'get_cookie2.html', {'com_name':com_name})

def del_cookie(request):
    response = render(request, 'del_cookie2.html')
    response.delete_cookie('com_name')
    return response


