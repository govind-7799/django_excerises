from django.shortcuts import render, HttpResponse
from django.views import View
from .forms import contactForm
from django.views.generic.base import TemplateView


# Create your views here.
# class home(View):
#     name = 'bhargav'
#     def get(self, request):
#         return HttpResponse(self.name)
#
# class home2(home):
#     def get(self, request):
#         return HttpResponse(self.name)

# class contactClassView(View):
#     # name = 'bhargav'
#     def get(self,request):
#         form = contactForm()
#         return render(request, 'index.html', {'form':form})
#
#     def post(self, request):
#         form = contactForm(request.POST)
#         if form.is_valid():
#             print(form.cleaned_data['name'])
#             return HttpResponse('your form got submitted')

class template_view(TemplateView):
    template_name = 'index.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['name'] = 'Suraj'
        context['id']   = 213334343655
        print(context)
        return context